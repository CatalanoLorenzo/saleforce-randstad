import { LightningElement,api } from 'lwc';

export default class ShowLastRecord extends LightningElement {
    @api recordList;
}